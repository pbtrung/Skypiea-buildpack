extern char * mkdtemp(char *);
