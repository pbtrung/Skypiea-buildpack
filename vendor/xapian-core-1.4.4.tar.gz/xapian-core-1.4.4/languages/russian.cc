/* This file was generated automatically by the Snowball to ISO C++ compiler */
/* http://snowballstem.org/ */

#include <config.h>
#include <limits.h>
#include "russian.h"

#define s_0_0 (s_0_1 + 2)
static const symbol s_pool[] = {
#define s_0_1 0
0xD1, 0x8B, 0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8, 0xD1, 0x81, 0xD1, 0x8C,
#define s_0_2 12
0xD0, 0xB8, 0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8, 0xD1, 0x81, 0xD1, 0x8C,
#define s_0_3 s_0_0
#define s_0_4 s_0_1
#define s_0_5 s_0_2
#define s_0_6 s_0_0
#define s_0_7 s_0_1
#define s_0_8 s_0_2
#define s_1_0 24
0xD0, 0xB5, 0xD0, 0xBC, 0xD1, 0x83,
#define s_1_1 30
0xD0, 0xBE, 0xD0, 0xBC, 0xD1, 0x83,
#define s_1_2 36
0xD1, 0x8B, 0xD1, 0x85,
#define s_1_3 40
0xD0, 0xB8, 0xD1, 0x85,
#define s_1_4 44
0xD1, 0x83, 0xD1, 0x8E,
#define s_1_5 48
0xD1, 0x8E, 0xD1, 0x8E,
#define s_1_6 52
0xD0, 0xB5, 0xD1, 0x8E,
#define s_1_7 56
0xD0, 0xBE, 0xD1, 0x8E,
#define s_1_8 60
0xD1, 0x8F, 0xD1, 0x8F,
#define s_1_9 64
0xD0, 0xB0, 0xD1, 0x8F,
#define s_1_10 68
0xD1, 0x8B, 0xD0, 0xB5,
#define s_1_11 72
0xD0, 0xB5, 0xD0, 0xB5,
#define s_1_12 76
0xD0, 0xB8, 0xD0, 0xB5,
#define s_1_13 80
0xD0, 0xBE, 0xD0, 0xB5,
#define s_1_14 84
0xD1, 0x8B, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_1_15 90
0xD0, 0xB8, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_1_16 96
0xD1, 0x8B, 0xD0, 0xB9,
#define s_1_17 100
0xD0, 0xB5, 0xD0, 0xB9,
#define s_1_18 104
0xD0, 0xB8, 0xD0, 0xB9,
#define s_1_19 108
0xD0, 0xBE, 0xD0, 0xB9,
#define s_1_20 s_1_14
#define s_1_21 s_1_0
#define s_1_22 s_1_15
#define s_1_23 s_1_1
#define s_1_24 112
0xD0, 0xB5, 0xD0, 0xB3, 0xD0, 0xBE,
#define s_1_25 118
0xD0, 0xBE, 0xD0, 0xB3, 0xD0, 0xBE,
#define s_2_0 (s_2_1 + 2)
#define s_2_1 124
0xD1, 0x8B, 0xD0, 0xB2, 0xD1, 0x88,
#define s_2_2 130
0xD0, 0xB8, 0xD0, 0xB2, 0xD1, 0x88,
#define s_2_3 (s_2_4 + 2)
#define s_2_4 (s_2_5 + 2)
#define s_2_5 136
0xD1, 0x83, 0xD1, 0x8E, 0xD1, 0x89,
#define s_2_6 142
0xD0, 0xB5, 0xD0, 0xBC,
#define s_2_7 146
0xD0, 0xBD, 0xD0, 0xBD,
#define s_3_0 150
0xD1, 0x81, 0xD1, 0x8C,
#define s_3_1 154
0xD1, 0x81, 0xD1, 0x8F,
#define s_4_0 s_4_10
#define s_4_1 (s_4_2 + 2)
#define s_4_2 158
0xD1, 0x83, 0xD1, 0x8E, 0xD1, 0x82,
#define s_4_3 164
0xD1, 0x8F, 0xD1, 0x82,
#define s_4_4 (s_4_5 + 2)
#define s_4_5 168
0xD1, 0x83, 0xD0, 0xB5, 0xD1, 0x82,
#define s_4_6 s_4_11
#define s_4_7 (s_4_8 + 2)
#define s_4_8 174
0xD0, 0xB5, 0xD0, 0xBD, 0xD1, 0x8B,
#define s_4_9 (s_4_10 + 2)
#define s_4_10 180
0xD1, 0x8B, 0xD1, 0x82, 0xD1, 0x8C,
#define s_4_11 186
0xD0, 0xB8, 0xD1, 0x82, 0xD1, 0x8C,
#define s_4_12 192
0xD0, 0xB5, 0xD1, 0x88, 0xD1, 0x8C,
#define s_4_13 198
0xD0, 0xB8, 0xD1, 0x88, 0xD1, 0x8C,
#define s_4_14 s_4_1
#define s_4_15 s_4_2
#define s_4_16 (s_4_17 + 2)
#define s_4_17 204
0xD1, 0x8B, 0xD0, 0xBB, 0xD0, 0xB0,
#define s_4_18 210
0xD0, 0xB8, 0xD0, 0xBB, 0xD0, 0xB0,
#define s_4_19 (s_4_20 + 2)
#define s_4_20 216
0xD0, 0xB5, 0xD0, 0xBD, 0xD0, 0xB0,
#define s_4_21 222
0xD0, 0xB5, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_22 228
0xD0, 0xB8, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_23 (s_4_24 + 2)
#define s_4_24 234
0xD1, 0x83, 0xD0, 0xB9, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_25 242
0xD0, 0xB5, 0xD0, 0xB9, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_26 (s_4_27 + 2)
#define s_4_27 250
0xD1, 0x8B, 0xD0, 0xBB, 0xD0, 0xB8,
#define s_4_28 256
0xD0, 0xB8, 0xD0, 0xBB, 0xD0, 0xB8,
#define s_4_29 s_4_23
#define s_4_30 s_4_24
#define s_4_31 s_4_25
#define s_4_32 s_4_16
#define s_4_33 s_4_17
#define s_4_34 s_4_18
#define s_4_35 262
0xD1, 0x8B, 0xD0, 0xBC,
#define s_4_36 266
0xD0, 0xB5, 0xD0, 0xBC,
#define s_4_37 270
0xD0, 0xB8, 0xD0, 0xBC,
#define s_4_38 s_4_7
#define s_4_39 s_4_8
#define s_4_40 (s_4_41 + 2)
#define s_4_41 274
0xD1, 0x8B, 0xD0, 0xBB, 0xD0, 0xBE,
#define s_4_42 280
0xD0, 0xB8, 0xD0, 0xBB, 0xD0, 0xBE,
#define s_4_43 (s_4_44 + 2)
#define s_4_44 286
0xD0, 0xB5, 0xD0, 0xBD, 0xD0, 0xBE,
#define s_4_45 292
0xD0, 0xBD, 0xD0, 0xBD, 0xD0, 0xBE,
#define s_5_0 298
0xD1, 0x83,
#define s_5_1 (s_5_2 + 2)
#define s_5_2 300
0xD0, 0xB8, 0xD1, 0x8F, 0xD1, 0x85,
#define s_5_3 306
0xD0, 0xB0, 0xD1, 0x85,
#define s_5_4 310
0xD1, 0x8B,
#define s_5_5 s_5_7
#define s_5_6 (s_5_7 + 2)
#define s_5_7 312
0xD1, 0x8C, 0xD1, 0x8E,
#define s_5_8 316
0xD0, 0xB8, 0xD1, 0x8E,
#define s_5_9 s_5_1
#define s_5_10 320
0xD1, 0x8C, 0xD1, 0x8F,
#define s_5_11 s_5_2
#define s_5_12 s_5_3
#define s_5_13 324
0xD0, 0xB5, 0xD0, 0xB2,
#define s_5_14 328
0xD0, 0xBE, 0xD0, 0xB2,
#define s_5_15 s_5_13
#define s_5_16 332
0xD1, 0x8C, 0xD0, 0xB5,
#define s_5_17 s_5_26
#define s_5_18 s_5_2
#define s_5_19 336
0xD0, 0xB5, 0xD0, 0xB8,
#define s_5_20 340
0xD0, 0xB8, 0xD0, 0xB8,
#define s_5_21 (s_5_22 + 2)
#define s_5_22 344
0xD0, 0xB8, 0xD1, 0x8F, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_5_23 352
0xD0, 0xB0, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_5_24 (s_5_25 + 2)
#define s_5_25 (s_5_26 + 2)
#define s_5_26 358
0xD0, 0xB8, 0xD0, 0xB5, 0xD0, 0xB9,
#define s_5_27 364
0xD0, 0xB8, 0xD0, 0xB9,
#define s_5_28 368
0xD0, 0xBE, 0xD0, 0xB9,
#define s_5_29 s_5_21
#define s_5_30 s_5_22
#define s_5_31 s_5_23
#define s_5_32 (s_5_33 + 2)
#define s_5_33 372
0xD0, 0xB8, 0xD0, 0xB5, 0xD0, 0xBC,
#define s_5_34 378
0xD0, 0xBE, 0xD0, 0xBC,
#define s_5_35 s_5_14
#define s_6_0 s_6_1
#define s_6_1 382
0xD0, 0xBE, 0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x8C,
#define s_7_0 s_7_2
#define s_7_1 390
0xD1, 0x8C,
#define s_7_2 392
0xD0, 0xB5, 0xD0, 0xB9, 0xD1, 0x88, 0xD0, 0xB5,
#define s_7_3 400
0xD0, 0xBD,
};


static const struct among a_0[9] =
{
/*  0 */ { 10, s_0_0, -1, 1},
/*  1 */ { 12, s_0_1, 0, 2},
/*  2 */ { 12, s_0_2, 0, 2},
/*  3 */ { 2, s_0_3, -1, 1},
/*  4 */ { 4, s_0_4, 3, 2},
/*  5 */ { 4, s_0_5, 3, 2},
/*  6 */ { 6, s_0_6, -1, 1},
/*  7 */ { 8, s_0_7, 6, 2},
/*  8 */ { 8, s_0_8, 6, 2}
};


static const struct among a_1[26] =
{
/*  0 */ { 6, s_1_0, -1, 1},
/*  1 */ { 6, s_1_1, -1, 1},
/*  2 */ { 4, s_1_2, -1, 1},
/*  3 */ { 4, s_1_3, -1, 1},
/*  4 */ { 4, s_1_4, -1, 1},
/*  5 */ { 4, s_1_5, -1, 1},
/*  6 */ { 4, s_1_6, -1, 1},
/*  7 */ { 4, s_1_7, -1, 1},
/*  8 */ { 4, s_1_8, -1, 1},
/*  9 */ { 4, s_1_9, -1, 1},
/* 10 */ { 4, s_1_10, -1, 1},
/* 11 */ { 4, s_1_11, -1, 1},
/* 12 */ { 4, s_1_12, -1, 1},
/* 13 */ { 4, s_1_13, -1, 1},
/* 14 */ { 6, s_1_14, -1, 1},
/* 15 */ { 6, s_1_15, -1, 1},
/* 16 */ { 4, s_1_16, -1, 1},
/* 17 */ { 4, s_1_17, -1, 1},
/* 18 */ { 4, s_1_18, -1, 1},
/* 19 */ { 4, s_1_19, -1, 1},
/* 20 */ { 4, s_1_20, -1, 1},
/* 21 */ { 4, s_1_21, -1, 1},
/* 22 */ { 4, s_1_22, -1, 1},
/* 23 */ { 4, s_1_23, -1, 1},
/* 24 */ { 6, s_1_24, -1, 1},
/* 25 */ { 6, s_1_25, -1, 1}
};


static const struct among a_2[8] =
{
/*  0 */ { 4, s_2_0, -1, 1},
/*  1 */ { 6, s_2_1, 0, 2},
/*  2 */ { 6, s_2_2, 0, 2},
/*  3 */ { 2, s_2_3, -1, 1},
/*  4 */ { 4, s_2_4, 3, 1},
/*  5 */ { 6, s_2_5, 4, 2},
/*  6 */ { 4, s_2_6, -1, 1},
/*  7 */ { 4, s_2_7, -1, 1}
};


static const struct among a_3[2] =
{
/*  0 */ { 4, s_3_0, -1, 1},
/*  1 */ { 4, s_3_1, -1, 1}
};


static const struct among a_4[46] =
{
/*  0 */ { 4, s_4_0, -1, 2},
/*  1 */ { 4, s_4_1, -1, 1},
/*  2 */ { 6, s_4_2, 1, 2},
/*  3 */ { 4, s_4_3, -1, 2},
/*  4 */ { 4, s_4_4, -1, 1},
/*  5 */ { 6, s_4_5, 4, 2},
/*  6 */ { 4, s_4_6, -1, 2},
/*  7 */ { 4, s_4_7, -1, 1},
/*  8 */ { 6, s_4_8, 7, 2},
/*  9 */ { 4, s_4_9, -1, 1},
/* 10 */ { 6, s_4_10, 9, 2},
/* 11 */ { 6, s_4_11, 9, 2},
/* 12 */ { 6, s_4_12, -1, 1},
/* 13 */ { 6, s_4_13, -1, 2},
/* 14 */ { 2, s_4_14, -1, 2},
/* 15 */ { 4, s_4_15, 14, 2},
/* 16 */ { 4, s_4_16, -1, 1},
/* 17 */ { 6, s_4_17, 16, 2},
/* 18 */ { 6, s_4_18, 16, 2},
/* 19 */ { 4, s_4_19, -1, 1},
/* 20 */ { 6, s_4_20, 19, 2},
/* 21 */ { 6, s_4_21, -1, 1},
/* 22 */ { 6, s_4_22, -1, 2},
/* 23 */ { 6, s_4_23, -1, 1},
/* 24 */ { 8, s_4_24, 23, 2},
/* 25 */ { 8, s_4_25, 23, 2},
/* 26 */ { 4, s_4_26, -1, 1},
/* 27 */ { 6, s_4_27, 26, 2},
/* 28 */ { 6, s_4_28, 26, 2},
/* 29 */ { 2, s_4_29, -1, 1},
/* 30 */ { 4, s_4_30, 29, 2},
/* 31 */ { 4, s_4_31, 29, 2},
/* 32 */ { 2, s_4_32, -1, 1},
/* 33 */ { 4, s_4_33, 32, 2},
/* 34 */ { 4, s_4_34, 32, 2},
/* 35 */ { 4, s_4_35, -1, 2},
/* 36 */ { 4, s_4_36, -1, 1},
/* 37 */ { 4, s_4_37, -1, 2},
/* 38 */ { 2, s_4_38, -1, 1},
/* 39 */ { 4, s_4_39, 38, 2},
/* 40 */ { 4, s_4_40, -1, 1},
/* 41 */ { 6, s_4_41, 40, 2},
/* 42 */ { 6, s_4_42, 40, 2},
/* 43 */ { 4, s_4_43, -1, 1},
/* 44 */ { 6, s_4_44, 43, 2},
/* 45 */ { 6, s_4_45, 43, 1}
};


static const struct among a_5[36] =
{
/*  0 */ { 2, s_5_0, -1, 1},
/*  1 */ { 4, s_5_1, -1, 1},
/*  2 */ { 6, s_5_2, 1, 1},
/*  3 */ { 4, s_5_3, -1, 1},
/*  4 */ { 2, s_5_4, -1, 1},
/*  5 */ { 2, s_5_5, -1, 1},
/*  6 */ { 2, s_5_6, -1, 1},
/*  7 */ { 4, s_5_7, 6, 1},
/*  8 */ { 4, s_5_8, 6, 1},
/*  9 */ { 2, s_5_9, -1, 1},
/* 10 */ { 4, s_5_10, 9, 1},
/* 11 */ { 4, s_5_11, 9, 1},
/* 12 */ { 2, s_5_12, -1, 1},
/* 13 */ { 4, s_5_13, -1, 1},
/* 14 */ { 4, s_5_14, -1, 1},
/* 15 */ { 2, s_5_15, -1, 1},
/* 16 */ { 4, s_5_16, 15, 1},
/* 17 */ { 4, s_5_17, 15, 1},
/* 18 */ { 2, s_5_18, -1, 1},
/* 19 */ { 4, s_5_19, 18, 1},
/* 20 */ { 4, s_5_20, 18, 1},
/* 21 */ { 6, s_5_21, 18, 1},
/* 22 */ { 8, s_5_22, 21, 1},
/* 23 */ { 6, s_5_23, 18, 1},
/* 24 */ { 2, s_5_24, -1, 1},
/* 25 */ { 4, s_5_25, 24, 1},
/* 26 */ { 6, s_5_26, 25, 1},
/* 27 */ { 4, s_5_27, 24, 1},
/* 28 */ { 4, s_5_28, 24, 1},
/* 29 */ { 4, s_5_29, -1, 1},
/* 30 */ { 6, s_5_30, 29, 1},
/* 31 */ { 4, s_5_31, -1, 1},
/* 32 */ { 4, s_5_32, -1, 1},
/* 33 */ { 6, s_5_33, 32, 1},
/* 34 */ { 4, s_5_34, -1, 1},
/* 35 */ { 2, s_5_35, -1, 1}
};


static const struct among a_6[2] =
{
/*  0 */ { 6, s_6_0, -1, 1},
/*  1 */ { 8, s_6_1, -1, 1}
};


static const struct among a_7[4] =
{
/*  0 */ { 6, s_7_0, -1, 1},
/*  1 */ { 2, s_7_1, -1, 3},
/*  2 */ { 8, s_7_2, -1, 1},
/*  3 */ { 2, s_7_3, -1, 2}
};

static const unsigned char g_v[] = { 33, 65, 8, 232 };

static const symbol s_0[] = { 0xD0, 0xB0 };
static const symbol s_1[] = { 0xD1, 0x8F };
static const symbol s_2[] = { 0xD0, 0xB0 };
static const symbol s_3[] = { 0xD1, 0x8F };
static const symbol s_4[] = { 0xD0, 0xB0 };
static const symbol s_5[] = { 0xD1, 0x8F };
static const symbol s_6[] = { 0xD0, 0xBD };
static const symbol s_7[] = { 0xD0, 0xBD };
static const symbol s_8[] = { 0xD0, 0xBD };
static const symbol s_9[] = { 0xD0, 0xB8 };

int Xapian::InternalStemRussian::r_mark_regions() { /* forwardmode */
    I_pV = l; /* $pV = <integer expression>, line 61 */
    I_p2 = l; /* $p2 = <integer expression>, line 62 */
    {   int c1 = c; /* do, line 63 */
        {    /* gopast */ /* grouping v, line 64 */
            int ret = out_grouping_U(g_v, 1072, 1103, 1);
            if (ret < 0) goto lab0;
            c += ret;
        }
        I_pV = c; /* setmark pV, line 64 */
        {    /* gopast */ /* non v, line 64 */
            int ret = in_grouping_U(g_v, 1072, 1103, 1);
            if (ret < 0) goto lab0;
            c += ret;
        }
        {    /* gopast */ /* grouping v, line 65 */
            int ret = out_grouping_U(g_v, 1072, 1103, 1);
            if (ret < 0) goto lab0;
            c += ret;
        }
        {    /* gopast */ /* non v, line 65 */
            int ret = in_grouping_U(g_v, 1072, 1103, 1);
            if (ret < 0) goto lab0;
            c += ret;
        }
        I_p2 = c; /* setmark p2, line 65 */
    lab0:
        c = c1;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_R2() { /* backwardmode */
    if (!(I_p2 <= c)) return 0; /* $p2 <= <integer expression>, line 71 */
    return 1;
}

int Xapian::InternalStemRussian::r_perfective_gerund() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 74 */
    among_var = find_among_b(s_pool, a_0, 9, 0, 0); /* substring, line 74 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 74 */
    switch (among_var) { /* among, line 74 */
        case 0: return 0;
        case 1:
            {   int m1 = l - c; /*(void)m1*/; /* or, line 78 */
                if (!(eq_s_b(2, s_0))) goto lab1; /* literal, line 78 */
                goto lab0;
            lab1:
                c = l - m1;
                if (!(eq_s_b(2, s_1))) return 0; /* literal, line 78 */
            }
        lab0:
            if (slice_del() == -1) return -1; /* delete, line 78 */
            break;
        case 2:
            if (slice_del() == -1) return -1; /* delete, line 85 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_adjective() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 90 */
    among_var = find_among_b(s_pool, a_1, 26, 0, 0); /* substring, line 90 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 90 */
    switch (among_var) { /* among, line 90 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 99 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_adjectival() { /* backwardmode */
    int among_var;
    {   int ret = r_adjective(); /* call adjective, line 104 */
        if (ret <= 0) return ret;
    }
    {   int m1 = l - c; /*(void)m1*/; /* try, line 111 */
        ket = c; /* [, line 112 */
        among_var = find_among_b(s_pool, a_2, 8, 0, 0); /* substring, line 112 */
        if (!(among_var)) { c = l - m1; goto lab0; }
        bra = c; /* ], line 112 */
        switch (among_var) { /* among, line 112 */
            case 0: { c = l - m1; goto lab0; }
            case 1:
                {   int m2 = l - c; /*(void)m2*/; /* or, line 117 */
                    if (!(eq_s_b(2, s_2))) goto lab2; /* literal, line 117 */
                    goto lab1;
                lab2:
                    c = l - m2;
                    if (!(eq_s_b(2, s_3))) { c = l - m1; goto lab0; } /* literal, line 117 */
                }
            lab1:
                if (slice_del() == -1) return -1; /* delete, line 117 */
                break;
            case 2:
                if (slice_del() == -1) return -1; /* delete, line 124 */
                break;
        }
    lab0:
        ;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_reflexive() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 131 */
    if (c - 3 <= lb || (p[c - 1] != 140 && p[c - 1] != 143)) return 0; /* substring, line 131 */
    among_var = find_among_b(s_pool, a_3, 2, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 131 */
    switch (among_var) { /* among, line 131 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 134 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_verb() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 139 */
    among_var = find_among_b(s_pool, a_4, 46, 0, 0); /* substring, line 139 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 139 */
    switch (among_var) { /* among, line 139 */
        case 0: return 0;
        case 1:
            {   int m1 = l - c; /*(void)m1*/; /* or, line 145 */
                if (!(eq_s_b(2, s_4))) goto lab1; /* literal, line 145 */
                goto lab0;
            lab1:
                c = l - m1;
                if (!(eq_s_b(2, s_5))) return 0; /* literal, line 145 */
            }
        lab0:
            if (slice_del() == -1) return -1; /* delete, line 145 */
            break;
        case 2:
            if (slice_del() == -1) return -1; /* delete, line 153 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_noun() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 162 */
    among_var = find_among_b(s_pool, a_5, 36, 0, 0); /* substring, line 162 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 162 */
    switch (among_var) { /* among, line 162 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 169 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_derivational() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 178 */
    if (c - 5 <= lb || (p[c - 1] != 130 && p[c - 1] != 140)) return 0; /* substring, line 178 */
    among_var = find_among_b(s_pool, a_6, 2, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 178 */
    {   int ret = r_R2(); /* call R2, line 178 */
        if (ret <= 0) return ret;
    }
    switch (among_var) { /* among, line 178 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 181 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_tidy_up() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 186 */
    among_var = find_among_b(s_pool, a_7, 4, 0, 0); /* substring, line 186 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 186 */
    switch (among_var) { /* among, line 186 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 190 */
            ket = c; /* [, line 191 */
            if (!(eq_s_b(2, s_6))) return 0; /* literal, line 191 */
            bra = c; /* ], line 191 */
            if (!(eq_s_b(2, s_7))) return 0; /* literal, line 191 */
            if (slice_del() == -1) return -1; /* delete, line 191 */
            break;
        case 2:
            if (!(eq_s_b(2, s_8))) return 0; /* literal, line 194 */
            if (slice_del() == -1) return -1; /* delete, line 194 */
            break;
        case 3:
            if (slice_del() == -1) return -1; /* delete, line 196 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::stem() { /* forwardmode */
    {   int c1 = c; /* do, line 203 */
        {   int ret = r_mark_regions(); /* call mark_regions, line 203 */
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
    lab0:
        c = c1;
    }
    lb = c; c = l; /* backwards, line 204 */

    {   int m2 = l - c; /*(void)m2*/; /* setlimit, line 204 */
        int mlimit2;
        if (c < I_pV) return 0;
        c = I_pV; /* tomark, line 204 */
        mlimit2 = lb; lb = c;
        c = l - m2;
        {   int m3 = l - c; /*(void)m3*/; /* do, line 205 */
            {   int m4 = l - c; /*(void)m4*/; /* or, line 206 */
                {   int ret = r_perfective_gerund(); /* call perfective_gerund, line 206 */
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                goto lab2;
            lab3:
                c = l - m4;
                {   int m5 = l - c; /*(void)m5*/; /* try, line 207 */
                    {   int ret = r_reflexive(); /* call reflexive, line 207 */
                        if (ret == 0) { c = l - m5; goto lab4; }
                        if (ret < 0) return ret;
                    }
                lab4:
                    ;
                }
                {   int m6 = l - c; /*(void)m6*/; /* or, line 208 */
                    {   int ret = r_adjectival(); /* call adjectival, line 208 */
                        if (ret == 0) goto lab6;
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab6:
                    c = l - m6;
                    {   int ret = r_verb(); /* call verb, line 208 */
                        if (ret == 0) goto lab7;
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab7:
                    c = l - m6;
                    {   int ret = r_noun(); /* call noun, line 208 */
                        if (ret == 0) goto lab1;
                        if (ret < 0) return ret;
                    }
                }
            lab5:
                ;
            }
        lab2:
        lab1:
            c = l - m3;
        }
        {   int m7 = l - c; /*(void)m7*/; /* try, line 211 */
            ket = c; /* [, line 211 */
            if (!(eq_s_b(2, s_9))) { c = l - m7; goto lab8; } /* literal, line 211 */
            bra = c; /* ], line 211 */
            if (slice_del() == -1) return -1; /* delete, line 211 */
        lab8:
            ;
        }
        {   int m8 = l - c; /*(void)m8*/; /* do, line 214 */
            {   int ret = r_derivational(); /* call derivational, line 214 */
                if (ret == 0) goto lab9;
                if (ret < 0) return ret;
            }
        lab9:
            c = l - m8;
        }
        {   int m9 = l - c; /*(void)m9*/; /* do, line 215 */
            {   int ret = r_tidy_up(); /* call tidy_up, line 215 */
                if (ret == 0) goto lab10;
                if (ret < 0) return ret;
            }
        lab10:
            c = l - m9;
        }
        lb = mlimit2;
    }
    c = lb;
    return 1;
}

Xapian::InternalStemRussian::InternalStemRussian()
    : I_p2(0), I_pV(0)
{
}

Xapian::InternalStemRussian::~InternalStemRussian()
{
}

std::string
Xapian::InternalStemRussian::get_description() const
{
    return "russian";
}
